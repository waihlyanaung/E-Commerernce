import React from "react";
import { Route, Routes } from "react-router-dom";
import "./App.css";
import Guard from "./Component/Guard"
import Dashboard from "./pages/Dashboard";
// 1
import Login from "./pages/Login";
const App = () => {
    return (
        <>
            <Routes>
            <Route
          path="/"
          element={
            <Guard>
              <Dashboard />
            </Guard>
          }
        />  <Route path="/login" element={<Login />} /> 
            </Routes>
        </>
    );
};
export default App;