import React from 'react'

// import Products from './Pages/Product'
const Dashboard = () => {
  return (
    <div>
      ddd
     
    </div>
  )
}

export default Dashboard